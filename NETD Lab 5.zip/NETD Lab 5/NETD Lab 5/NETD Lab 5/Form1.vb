﻿Option Strict On
Imports System.IO

Public Class frmTextEditor
#Region "Declarations"
    Dim openFilePath As String = String.Empty
    Dim saveLocation As String = String.Empty
    Dim selectedText As String
    Dim highlitedText As String
#End Region

#Region "Events"
    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        MessageBox.Show("NetD-2202" & vbCrLf & "Lab # 5" & vbCrLf & "Navpreet Kanda")
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click

        'Call ShowDialog.
        Dim openFile As FileStream
        Dim fileReader As StreamReader


        'Test result.
        If ofdOpen.ShowDialog() = DialogResult.OK Then

            ' Get the file path.
            openFilePath = ofdOpen.FileName
            openFile = New FileStream(openFilePath, FileMode.Open, FileAccess.Read)
            fileReader = New StreamReader(openFile)
            tbOutput.Text = fileReader.ReadToEnd
        End If
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        ' Sets default saving to text file format
        sfdSaveAs.Filter = "TXT Files (*.txt*)|*.txt"

        'Check to see if there is a current saveLocation
        If saveLocation = "" Then
            sfdSaveAs.ShowDialog()
            saveLocation = sfdSaveAs.FileName
            SaveFile(saveLocation)
        Else
            SaveFile(saveLocation)

        End If
    End Sub

    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click
        ' Location of file path
        Dim location As String
        ' Sets default saving to text file format
        sfdSaveAs.Filter = "TXT Files (*.txt*)|*.txt"
        If sfdSaveAs.ShowDialog() = DialogResult.OK Then
            location = sfdSaveAs.FileName
            SaveFile(location)
        End If
    End Sub

    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click
        tbOutput.Clear()
        saveLocation = String.Empty
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click

        highlitedText = tbOutput.SelectedText
        If Not highlitedText = String.Empty Then
            CopyText(highlitedText)
        End If
    End Sub

    Private Sub mnuEditPaste_Click(sender As Object, e As EventArgs) Handles mnuEditPaste.Click
        PasteText(selectedText)
    End Sub

    Private Sub mnuEditCut_Click(sender As Object, e As EventArgs) Handles mnuEditCut.Click
        highlitedText = tbOutput.SelectedText
        tbOutput.SelectedText = ""
        If Not highlitedText = String.Empty Then
            CutText(highlitedText)
        End If
    End Sub
#End Region


#Region "Methods"

    Friend Sub CutText(selectedText As String)

        My.Computer.Clipboard.SetText(selectedText)
    End Sub

    Friend Sub CopyText(selectedText As String)

        My.Computer.Clipboard.SetText(selectedText)

    End Sub

    Friend Sub PasteText(pastedText As String)
        tbOutput.Paste(Clipboard.GetText())

    End Sub
    Friend Sub SaveFile(path As String)
        ' Create a new FileStream object
        Dim SavedDocument As FileStream = New FileStream(path, FileMode.Create, FileAccess.Write)

        ' Create a new StreamWriter object
        ' Using the FileStream object as a constructor

        Dim writer As New StreamWriter(SavedDocument)
        writer.Write(tbOutput.Text)
        writer.Close()
    End Sub
#End Region

End Class
